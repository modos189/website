// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Portal Names
// @category       Layer
// @version        0.2.4.20260302.090744
// @description    Show portal names on the map.
// @id             portal-names
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/portal-names.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/portal-names.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/portal-names.svg
// @grant          none
// ==/UserScript==
